import { React } from "react";
import { Link } from "react-router-dom";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
function register(){
  return (
    <div>
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            {/* trzeba z tego formularz zrobic */}
            <h1 className="naglowki">Rejestracja</h1>
            <p className="info">Adres e-mail:</p>
            <TextField className="email" placeholder="przykład@gmail.com"></TextField>
            <p className="info">Hasło:</p>
            <TextField className="haslo" type="password"></TextField>
            <Link to="/">
            <input className="registerbutton2" type="button" value="ZAREJESTRUJ"></input>
            </Link>
          </section>
        </section>
      </header>
    </div>
  );
}
export default register;