import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase.js";
import { Link } from "react-router-dom";
import TextField from "@mui/material/TextField";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';

// Lokalne obrazki przypisane do nazw produktów
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import UglyAssShoes from './zdjecia/UglyAssShoes.png';
import ShrekHeels from './zdjecia/ShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Ugly Ass Shoes": UglyAssShoes,
  "Shrek Heels": ShrekHeels,
};

function Glowna() {
  const [liczba, setLiczba] = useState(1);
  const [produkty, setProdukty] = useState([]);

  useEffect(() => {
    async function fetchProdukty() {
      const querySnapshot = await getDocs(collection(db, "Products"));
      const listaProduktow = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setProdukty(listaProduktow);
    }

    fetchProdukty();
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <section className="Section">
          <img src={logo} alt="Logo" className="Logo" />
          <div className="Search">
            <TextField
              id="SearchBar"
              variant="filled"
              fullWidth
              placeholder="Szukaj"
            />
          </div>
          <section className="Buttons">
            <Link to="/login">
              <img src={user} alt="User" className="User" />
              <p className="Logintext">Zaloguj się</p>
            </Link>
            <Link to="/koszyk" state={{ liczba }}>
              <img src={cart} alt="Cart" className="Cart" />
              <p className="Carttext">Koszyk</p>
            </Link>
          </section>
        </section>
        <section className="Section2">
          <table className="Table" id="table">
            <tbody>
              <tr>
                <td></td>
                <td className="Jeden">Specjalne Oferty</td>
                <td>Nowa Kolekcja</td>
                <td>Dziecięce</td>
                <td>Damskie</td>
                <td>Męskie</td>
                <td>Sportowe</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </section>
      </header>
      <section className="Section3">
      <table>
                <tr>
                  <td className="opcjeodst"></td>
                  <td>
                    <select className="opcje">
                      <option defaultValue>Rozmiar</option>
                      <option value="36">36</option>
                      <option value="37">37</option>
                      <option value="38">38</option>
                      <option value="39">39</option>
                      <option value="40">40</option>
                      <option value="41">41</option>
                      <option value="42">42</option>
                      <option value="43">43</option>
                      <option value="44">44</option>
                      <option value="45">45</option>
                      <option value="46">46</option>
                    </select>
                  </td>
                  <td>
                    <select className="opcje">
                      <option defaultValue>Kolor</option>
                      <option value="czarny">Czarny</option>
                      <option value="biały">Biały</option>
                      <option value="czerwony">Czerwony</option>
                      <option value="szary">Szary</option>
                      <option value="różowy">Różowy</option>
                      <option value="niebieski">Niebieski</option>
                      <option value="kolorowy">Inny</option>
                    </select>
                  </td>
                  <td>
                    <select className="opcje">
                      <option defaultValue>Cena</option>
                      <option value="malejąco">Malejąco</option>
                      <option value="rosnąco">Rosnąco</option>
                    </select>
                  </td>
                  <td>
                    <select className="opcje">
                      <option defaultValue>Marka</option>
                      <option value="adidas">Adidas</option>
                      <option value="puma">Puma</option>
                      <option value="nike">Nike</option>
                      <option value="reebok">Reebok</option>
                      <option value="newbalance">New Balance</option>
                      <option value="vans">Vans</option>
                      <option value="fila">Fila</option>
                    </select>
                  </td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </table>
      </section>
      <div id="produkty" className="produkty-grid">
        {produkty.length > 0 ? (
          produkty.map((produkt) => (
            <div className="infoprodukty" key={produkt.id}>
              <Link to="/produkt">
              <img
                src={obrazki[produkt.nazwa] || AbibosMax35}
                alt={produkt.nazwa}
                className="produkt-img"
              />
              </Link>
              <p><strong>Nazwa:</strong> {produkt.nazwa}</p>
              <p><strong>Cena:</strong> {produkt.cena} ZŁ</p>
            </div>
          ))
        ) : (
          <p className="info">Ładuję produkty...</p>
        )}
      </div>
    </div>
  );
}

export default Glowna;
