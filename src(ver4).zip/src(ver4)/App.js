import { React, useState } from "react";
import TextField from "@mui/material/TextField";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';
import search from './search.png';
import { Table } from "@mui/material";
function App() {
  return (
      <div className="App">
        <header className="App-header">
          <section className="Section">
            <img src={logo} alt="Logo" className="Logo" />
            <div className="Search">
              <TextField
                id="SearchBar"
                variant="filled"
                fullWidth
                placeholder="Szukaj"
              />
            </div>
            <section className="Buttons">
                <a href="https://youtube.com/">
                  <img src={user} alt="User" className="User" />
                  <p className="Logintext">Zaloguj się</p>
                </a>
                <a href="https://youtube.com/">
                  <img src={cart} alt="Cart" className="Cart" />
                  <p className="Carttext">Koszyk</p>
                </a>
            </section>
          </section>
          <section className="Section2">
            <Table className="Table" id="table">
              <tr>
              <td></td><td class="Jeden">Specjalne Oferty</td><td>Nowa Kolekcja</td><td>Marki</td><td>Dziecięce</td><td>Damskie</td><td>Męskie</td><td>Sportowe</td><td></td><td></td>
              </tr>
            </Table>
          </section>
        </header>
        <div id="produkty">
          <table id="sortowanie">
          <tr>
            <td></td>
            <td>sortuj</td>
            <td>rozmiar</td>
            <td>kolor</td>
            <td>cena</td>
            <td>marka</td>
          </tr>
        </table></div>
      </div>
  );
}
export default App;