import React, { useState } from "react";
import { Link } from "react-router-dom";
import './App.css';
import logo from './Logo.png';

function Produkt() {
  const [liczba, setLiczba] = useState(1);
  const [cena, setPrice] = useState(null);

  const zwiekszKoszyk = () => {
    setLiczba(prev => prev + 1);
  };

  return (
    <div>
      <header className="App-header">
        <section className="Section">
          <Link to="/">
            <img src={logo} alt="Logo" className="Logo" />
          </Link>
        </section>
      </header>
      <section>
        <p className="info">TUTAJ INFO PRODUKTU I DODAWANIE DO KOSZYKA</p>
        <button onClick={zwiekszKoszyk}>Dodaj do koszyka</button>
        <p>Ilość w koszyku: {liczba}</p>
      </section>
    </div>
  );
}

export default Produkt;
