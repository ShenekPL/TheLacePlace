import { React } from "react";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
import user from './user.png';
function Koszyk(){
    // ta wartosc bedzie zmieniana przy dodawaniu rzeczy do koszyka
    const location = useLocation();
  const liczba = location.state?.liczba || 0;
     let zawartosc;

     if (liczba === 1) {
      zawartosc = (
        <div>
           <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
                <section className="loginkoszyk">
                <Link to="/login">
                  <img src={user} alt="User " className="User " />
                  <p className="Logintext">Zaloguj się</p>
                </Link>
        </section>
        </section>
        </header>
        <section className="tla">
        <section className="tlokoszyk1">
          <h2 className="pustykoszh">Twój koszyk jest pusty</h2>
          <p className="pustykoszp">Dodaj produkty do koszyka</p>
        </section>
        <section className="tlokoszyk2">
          <section className="alignbuttons">
          <Link to="/">
          <button className="buttoncontinue">Kontynuuj zakupy</button>
          </Link>
          <Link to="/login">
          <button className="buttonlogin">Zaloguj się</button>
          </Link>
          </section>
        </section>
        </section>
        </div>
      );
     } else if (liczba > 1) {
      zawartosc = (
        <div>
           <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        </header>
          <h2>koszyk:({liczba})</h2>
          <p>itemki z kosza tutaj</p>
        </div>
      )
     }
    return(
        <div>
        {zawartosc}
        </div>
    );
}
export default Koszyk;