import { React } from "react";
import { Link } from "react-router-dom";
import mark from './Bardzo intencjonalnie dodane zdjęcie.jpg'; 
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
import Register from "./Register";
function Login(){
  return (
    <div>
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            {/* trzeba z tego formularz zrobic */}
            <h1 className="naglowki">Logowanie</h1>
            <p className="info">Adres e-mail:</p>
            <TextField className="email" placeholder="przykład@gmail.com"></TextField>
            <p className="info">Hasło:</p>
            <TextField className="haslo"></TextField>
            <input className="loginbutton" type="button" value="ZALOGUJ"></input><br/>
            <Link to="/Register">
            <input className="registerbutton" type="button" value="REJESTRACJA"></input>
            </Link>
          </section>
        </section>
      </header>
    </div>
  );
}
export default Login;