import { React, useState } from "react";
import TextField from "@mui/material/TextField";
import { Link, BrowserRouter, Routes, Route } from "react-router-dom";
import ReactDOM from "react-dom";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';
import Login from "./Login";
import Glowna from "./Glowna";
import Register from "./Register";

function App() {
  return (
    <>
      <BrowserRouter>
              <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route index element={<Glowna/>} />
        </Routes>
      </BrowserRouter>
    </>
  );
}


export default App;
