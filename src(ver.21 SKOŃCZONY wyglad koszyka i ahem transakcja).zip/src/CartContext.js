import React, { createContext, useContext, useState } from "react";

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  const addToCart = (produkt) => {
    setCart((prevCart) => {
      const istnieje = prevCart.find(
        (item) =>
          item.id === produkt.id &&
          item.kolor === produkt.kolor &&
          item.rozmiar === produkt.rozmiar
      );

      if (istnieje) {
        return prevCart.map((item) =>
          item.id === produkt.id &&
          item.kolor === produkt.kolor &&
          item.rozmiar === produkt.rozmiar
            ? { ...item, liczba: item.liczba + produkt.liczba }
            : item
        );
      } else {
        return [...prevCart, produkt];
      }
    });
  };

  const removeFromCart = (id) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  return (
    <CartContext.Provider value={{ cart, setCart, addToCart, removeFromCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}
