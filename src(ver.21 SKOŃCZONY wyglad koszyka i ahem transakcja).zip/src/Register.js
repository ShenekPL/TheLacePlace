import  React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { doCreateUserWithEmailAndPassword } from "./Auth";
import { useAuth } from "./AuthContext";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
function Register(){
  
  const navigate = useNavigate()
  
    const { userLoggedIn } = useAuth()

    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [confirmPassword, setConfirmPassword] = useState("")
    const [isRegistering, setIsRegistering] = useState(false)
    const [errorMessage, setErrorMessage] = useState('')
  
    const onSubmit = async (e) =>{
      e.preventDefault()
      if(!isRegistering){
        setIsRegistering(true)
        await doCreateUserWithEmailAndPassword(email, password)
      }
    }

  return (
    <div>
      {userLoggedIn && (<Navigate to={'/'} replace={true} />)}
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            {/* trzeba z tego formularz zrobic */}
            {/* już nie trzeba 👍*/}
            <form onSubmit={onSubmit}>
              <h1 className="naglowki">Rejestracja</h1>
              <p className="info">Adres e-mail:</p>
              <TextField className="email" placeholder="przykład@gmail.com" value={email} onChange={ (e) => setEmail(e.target.value)}/>
              <p className="info">Hasło:</p>
              <TextField className="haslo" type="password" value={password} onChange={ (e) => setPassword(e.target.value)} />
              <p className="info">Powtórz hasło:</p>
              <TextField className="haslo" type="password" value={confirmPassword} onChange={ (e) => setConfirmPassword(e.target.value)} />
                {errorMessage && (<p className="info" style="color: red;">{errorMessage}</p>)}  
              <input className="registerbutton2" type="submit" value="ZAREJESTRUJ" />
            </form>
          </section>
        </section>
      </header>
    </div>
  );
}
export default Register;