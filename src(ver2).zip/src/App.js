import { React, useState } from "react";
import TextField from "@mui/material/TextField";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <section className="Section">
          <img src={logo} alt="Logo" className="Logo" />
          <div className="Search">
            <TextField
              id="SearchBar"
              variant="filled"
              fullWidth
              placeholder="Search"
            />
          </div>
          <section className="buttons">
          <img src={user} alt="user" className="user"></img>
          <p className="logintext">Zaloguj się</p>
          <img src={cart} alt="cart" className="cart"></img>
          <p className="carttext">Koszyk</p>
          </section>
        </section>
        <section className="Section2">
          <p>Diddy</p>
        </section>
      </header>
    </div>
  );
}
export default App;