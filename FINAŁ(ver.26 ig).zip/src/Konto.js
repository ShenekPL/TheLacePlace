import  React, { useState, useEffect } from "react";
import { db } from "./firebase";
import { collection, addDoc, getDocs, query, orderBy, limit, doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { doSignOut } from "./Auth";
import logo from './Logo.png';
import user from './user.png';
import './App.css';
function Konto(){

  const  { currentUser } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState("");
  const [newProductData, setNewProductData] = useState({
    nazwa: "",
    cena: "",
    kategoria: "",
    kolor: "",
    marka: "",
    rozmiar: "",
    specjalnaOferta: false,
    sportowe: false
  });
  //const [adminEmail, setAdminEmail] = useState("");

  const handleAddProduct = async () => {
    const {
      nazwa,
      cena,
      kategoria,
      kolor,
      marka,
      rozmiar,
      specjalnaOferta,
      sportowe
    } = newProductData;

    if (!nazwa || !cena) {
      alert("Wypełnij wymagane pola: Nazwa i Cena.");
      return;
    }

    try {
      const productsRef = collection(db, "Products");
      const q = query(productsRef, orderBy("id", "desc"), limit(1));
      const querySnapshot = await getDocs(q);

      let nextId = 1;
      if (!querySnapshot.empty) {
        const lastDoc = querySnapshot.docs[0];
        const lastId = lastDoc.data().id;
        nextId = lastId + 1;
      }

      const productData = {
        id: nextId,
        nazwa,
        cena: parseFloat(cena),
        kategoria,
        kolor,
        marka,
        nowakolekcja: true,
        rozmiar: rozmiar.split(",").map((r) => r.trim()),
        specjalnaOferta,
        sportowe
      };

      await setDoc(doc(db, "Products", nextId.toString()), productData);

      alert("Produkt dodany");
      setNewProductData({
        id: "",
        nazwa: "",
        cena: "",
        kategoria: "",
        kolor: "",
        marka: "",
        rozmiar: "",
        specjalnaOferta: false,
        sportowe: false
      });
    } catch (error) {
      console.error("Błąd przy dodawaniu produktu:", error);
      alert("Wystąpił błąd.");
    }
  };


  useEffect(() => {
    const fetchUserRole = async () => {
      if (currentUser) {
        const docRef = doc(db, "users", currentUser.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setRole(docSnap.data().role);
        }
      }
    };
    fetchUserRole();
  }, [currentUser]);

  return (
    <div>
        <header className="App-header">
            <section className="Section">
            <Link to="/">
                <img src={logo} alt="Logo" className="Logo" />
            </Link>
            </section>
        </header>
        <h1 className="info" style={{textAlign: "center", fontSize: "30px"}}>Zalogowany jako: {currentUser.email}</h1>
        <Link to="/"><input type="button" className="loginbutton" onClick={doSignOut} value="Wyloguj się"/></Link>

        {role === "admin" && (
          <div style={{ textAlign: "center", marginTop: "40px" }}>
            <h2 className="info">Panel administratora</h2>
            <div className="admin-form">
              <p className="info">Nazwa:</p>
              <input className="inputyadmin"
                value={newProductData.nazwa}
                onChange={(e) => setNewProductData({ ...newProductData, nazwa: e.target.value })}
              />
              <p className="info">Cena:</p>
              <input  className="inputyadmin"               
                type="number"
                value={newProductData.cena}
                onChange={(e) => setNewProductData({ ...newProductData, cena: e.target.value })}
              />
              <p className="info">Kategoria:</p>
              <input   className="inputyadmin"              
                value={newProductData.kategoria}
                onChange={(e) => setNewProductData({ ...newProductData, kategoria: e.target.value })}
              />
              <p className="info">Kolor:</p>
              <input  className="inputyadmin"
                value={newProductData.kolor}
                onChange={(e) => setNewProductData({ ...newProductData, kolor: e.target.value })}
              />
              <p className="info">Marka:</p>
              <input  className="inputyadmin"               
                value={newProductData.marka}
                onChange={(e) => setNewProductData({ ...newProductData, marka: e.target.value })}
              />
              <p className="info">Rozmiary (oddzielone przecinkami):</p>
              <input   className="inputyadmin"
                value={newProductData.rozmiar}
                onChange={(e) => setNewProductData({ ...newProductData, rozmiar: e.target.value })}
              />
              <p className="info">Specjalna oferta:
              <input  className="checkboxadmin"
                type="checkbox"
                checked={newProductData.specjalnaOferta}
                onChange={(e) => setNewProductData({ ...newProductData, specjalnaOferta: e.target.checked })}
              /></p>
              <p className="info">Sportowe:
              <input className="checkboxadmin"
                type="checkbox"
                checked={newProductData.sportowe}
                onChange={(e) => setNewProductData({ ...newProductData, sportowe: e.target.checked })}
              /></p>
              <br />
              <button className="guzikadmin" onClick={handleAddProduct}>
                Dodaj produkt
              </button>
            </div>
          </div>
        )}

    </div>
  );
}
export default Konto;