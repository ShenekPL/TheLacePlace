import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { useCart } from "./CartContext";
import { useAuth } from "./AuthContext.jsx";
import './App.css';
import logo from './Logo.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Platnosc() {
  const { cart, clearCart } = useCart();
  const suma = cart.reduce((acc, item) => acc + item.cena * item.liczba, 0);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [Data, setData] = useState({
    address: "",
    phone: "",
    postal: "",
    email: "",
  });

  const Options = {
    "client-id": "Ach8VOWGSujpECnIS6okxUH4JZBReTN8C2W30tZQDRyy4IHxfA4wQNZy9okSdrKlpBH-2YUvFIHgqtFe",
    currency: "PLN",
    intent: "capture",
  };

  const createOrder = (data, actions) => {
    return actions.order.create({
      purchase_units: [
        {
          amount: {
            value: suma.toFixed(2),
            currency_code: "PLN",
          },
        },
      ],
    });
  };

  const onApprove = (data, actions) => {
    return actions.order.capture().then((details) => {
      alert("Zapłacono!");
      clearCart();
      navigate("/");
    });
  };

  const onError = (err) => {
    console.error("PayPal error", err);
    alert("Wystąpił błąd podczas przetwarzania płatności. Spróbuj ponownie.");
  };

  const isValid = () => {
    const { address, phone, postal, email } = Data;
    const phoneRegex = /^[0-9]{9}$/;
    const postalRegex = /^[0-9]{2}-[0-9]{3}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return (
      address.trim() !== "" &&
      phoneRegex.test(phone) &&
      postalRegex.test(postal) &&
      emailRegex.test(email)
    );
  };

  if (!currentUser) {
    navigate('/login');
    return null;
  }

  return (
    <div className="tlo">
      <header className="App-header">
        <section className="Section">
          <Link to="/">
            <img src={logo} alt="Logo" className="Logo" />
          </Link>
        </section>
      </header>

      <section className="tla" style={{ display: "flex", justifyContent: "center", alignItems: "flex-start", gap: "40px", paddingTop: "20px" }}>
        <div style={{ width: "480px" }}>
          <h2>Koszyk ({cart.length})</h2>
          <div className="cart-items">
            {cart.map((item, index) => {
              const imgSrc = obrazki[item.nazwa] || AbibosMax35;
              const nazwaPodzielona = item.nazwa.split(" ");
              return (
                <section className="produktytlo" key={index} style={{ paddingTop: "15px", paddingBottom: "5px", width: "450px" }}>
                  <div className="cart-item" style={{ display: "flex", alignItems: "center", marginBottom: "5px", marginLeft: "10px" }}>
                    <img src={imgSrc} alt={item.nazwa} style={{ width: "100px", height: "auto", marginRight: "20px" }} />
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "5px", minWidth: "300px" }}>
                        <span style={{ fontWeight: "bold" }}>{nazwaPodzielona[0]}</span>
                        <span style={{ fontWeight: "bold" }}>{(item.cena * item.liczba).toFixed(2)} ZŁ</span>
                      </div>
                      <span style={{ display: "block", marginBottom: "5px" }}>{nazwaPodzielona.slice(1).join(" ")}</span>
                      <span className="modelbuta" style={{ display: "block" }}>Kolor: {item.kolor}</span>
                      <span className="modelbuta" style={{ display: "block" }}>Rozmiar: {item.rozmiar}</span>
                    </div>
                  </div>
                </section>
              );
            })}
          </div>
        </div>

        {/* Prawa kolumna - podsumowanie */}
        <section className="podsumowanie">
          <p className="podsumowanietekst">Podsumowanie</p>
          <hr />
          <p className="podsumowaniep">Wartość produktów: {suma.toFixed(2)} ZŁ</p>
          <p className="podsumowaniep">Dostawa:</p>

          <input
            type="text"
            name="address"
            placeholder="Adres"
            required
            className="DataInput"
            value={Data.address}
            onChange={(e) => setData({ ...Data, address: e.target.value })}
          /><br />

          <input
            type="text"
            name="phone"
            placeholder="Numer telefonu (9 cyfr)"
            required
            className="DataInput"
            value={Data.phone}
            onChange={(e) => setData({ ...Data, phone: e.target.value })}
          /><br />

          <input
            type="text"
            name="postal"
            placeholder="Kod pocztowy (00-000)"
            required
            className="DataInput"
            value={Data.postal}
            onChange={(e) => setData({ ...Data, postal: e.target.value })}
          /><br />

          <input
            type="email"
            name="email"
            placeholder="Adres e-mail"
            required
            className="DataInput"
            value={Data.email}
            onChange={(e) => setData({ ...Data, email: e.target.value })}
          />

          <hr />
          <p className="podsumowanietekst">Do zapłaty (z VAT): {suma.toFixed(2)} ZŁ</p>

          <PayPalScriptProvider options={Options}>
            {isValid() ? (
              <PayPalButtons
                createOrder={createOrder}
                onApprove={onApprove}
                onError={onError}
              />
            ) : (
              <p style={{ color: "red" }}>
                Wszystkie pola powinny być wypełnione poprawnie.
              </p>
            )}
          </PayPalScriptProvider>
        </section>
      </section>
    </div>
  );
}

export default Platnosc;