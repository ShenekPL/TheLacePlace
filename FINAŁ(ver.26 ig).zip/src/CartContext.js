import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const loadCartFromFirestore = async () => {
      if (user) {
        const docRef = doc(db, 'carts', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setCart(docSnap.data().items || []);
        }
      }
    };

    loadCartFromFirestore();
  }, [user]);

  useEffect(() => {
    const saveCartToFirestore = async () => {
      if (user && cart.length > 0) {
        try {
          await setDoc(doc(db, 'carts', user.uid), {
            items: cart,
            updatedAt: new Date(),
          });
        } catch (error) {
          console.error('Błąd zapisu koszyka:', error);
        }
      }
    };

    saveCartToFirestore();
  }, [cart, user]);

  const addToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  const removeFromCart = (productToRemove) => {
  setCart((prevCart) =>
    prevCart.filter(
      (item, index) => !(item.id === productToRemove.id && item.rozmiar === productToRemove.rozmiar && index === productToRemove.index)
    )
  );
};

const clearCart = () => {
  setCart([]);
};

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
