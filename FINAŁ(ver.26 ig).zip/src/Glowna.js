import React, { useState, useEffect } from "react"; 
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase.js";
import { Link } from "react-router-dom";
import TextField from "@mui/material/TextField";
import { useAuth } from "./AuthContext.jsx";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';

import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Glowna() {
  const [liczba, setLiczba] = useState(1);
  const [produkty, setProdukty] = useState([]);
  const [filtr, setFiltr] = useState({
    rozmiar: "",
    kolor: "",
    cena: "",
    marka: "",
    kategoria: "",
    nowaKolekcja: false,
    specjalnaOferta: false,
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [przefiltrowane, setPrzefiltrowane] = useState([]);

  useEffect(() => {
    async function fetchProdukty() {
      const querySnapshot = await getDocs(collection(db, "Products"));
      const listaProduktow = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setProdukty(listaProduktow);
    }
    fetchProdukty();
  }, []);

  useEffect(() => {
    let wynik = [...produkty];

    if (searchTerm.trim() !== "") {
      const term = searchTerm.toLowerCase();
      wynik = wynik.filter(p => p.nazwa.toLowerCase().includes(term));
    }

    if (filtr.rozmiar) {
      const rozmiarNum = Number(filtr.rozmiar);
      wynik = wynik.filter(p => Array.isArray(p.rozmiar) && p.rozmiar.includes(rozmiarNum));
    }
    if (filtr.kolor) {
      wynik = wynik.filter(p => p.kolor?.toLowerCase() === filtr.kolor.toLowerCase());
    }
    if (filtr.marka) {
      wynik = wynik.filter(p => p.marka?.toLowerCase() === filtr.marka.toLowerCase());
    }

    if (filtr.nowaKolekcja) {
      wynik = wynik.filter(p => p.nowaKolekcja === true);
    } else if (filtr.specjalnaOferta) {
      wynik = wynik.filter(p => p.specjalnaOferta === true);
    } else if (filtr.kategoria) {
      if (filtr.kategoria === "sportowe") {
        wynik = wynik.filter(p => p.sportowe === true);
      } else {
        wynik = wynik.filter(p => p.kategoria?.toLowerCase() === filtr.kategoria.toLowerCase());
      }
    }

    if (filtr.cena === "rosnąco") {
      wynik.sort((a, b) => a.cena - b.cena);
    } else if (filtr.cena === "malejąco") {
      wynik.sort((a, b) => b.cena - a.cena);
    }

    setPrzefiltrowane(wynik);
  }, [produkty, filtr, searchTerm]);

  const zmienFiltr = (pole) => (e) => {
    setFiltr(prev => ({
      ...prev,
      [pole]: e.target.value
    }));
  };

  const ustawKategorie = (kategoria) => {
    if (kategoria === "wszystko") {
      // Resetuj wszystkie filtry kategorii
      setFiltr(prev => ({
        ...prev,
        kategoria: "",
        nowaKolekcja: false,
        specjalnaOferta: false
      }));
    } else {
      setFiltr(prev => ({
        ...prev,
        kategoria: "",
        nowaKolekcja: false,
        specjalnaOferta: false,
        ...(kategoria === "nowaKolekcja" && { nowaKolekcja: true }),
        ...(kategoria === "specjalnaOferta" && { specjalnaOferta: true }),
        ...(kategoria !== "nowaKolekcja" && kategoria !== "specjalnaOferta" && { kategoria }),
      }));
    }
    setSearchTerm("");
  };

  const { currentUser } = useAuth()
  let konto;

  if(currentUser != null){
    konto = (
      <Link to="/konto">
          <img src={user} alt="User" className="User" />
          <p className="Logintext">Mój profil</p>
      </Link>
    )
  }else{
    konto = (
      <Link to="/login">
          <img src={user} alt="User" className="User" />
          <p className="Logintext">Zaloguj się</p>
      </Link>
    )
  }

  return (
    <div className="App">
      <header className="App-header">
        <section className="Section">
          <img src={logo} alt="Logo" className="Logo" />
          <div className="Search">
            <TextField
              id="SearchBar"
              variant="filled"
              fullWidth
              placeholder="Szukaj"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <section className="Buttons">
            {konto}
            <Link to="/koszyk" state={{ liczba }}>
              <img src={cart} alt="Cart" className="Cart" />
              <p className="Carttext">Koszyk</p>
            </Link>
          </section>
        </section>
        <section className="Section2">
          <table className="Table" id="table">
            <tbody>
              <tr>
                <td></td>
                <td className={filtr.specjalnaOferta ? "Jeden selected-category" : "Jeden"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("specjalnaOferta")}>Specjalne Oferty</td>
                <td className={filtr.nowaKolekcja ? "wybor selected-category" : "wybor"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("nowaKolekcja")}>Nowa Kolekcja</td>
                <td className={filtr.kategoria === "dzieciece" ? "wybor selected-category" : "wybor"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("dzieciece")}>Dziecięce</td>
                <td className={filtr.kategoria === "damskie" ? "wybor selected-category" : "wybor"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("damskie")}>Damskie</td>
                <td className={filtr.kategoria === "meskie" ? "wybor selected-category" : "wybor"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("meskie")}>Męskie</td>
                <td className={filtr.kategoria === "sportowe" ? "wybor selected-category" : "wybor"} style={{ cursor: "pointer" }} onClick={() => ustawKategorie("sportowe")}>Sportowe</td>
                <td style={{ cursor: "pointer" }} onClick={() => ustawKategorie("wszystko")}>Wszystko</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </section>
      </header>

      <section className="Section3">
        <table className="tabelaopcji">
          <tbody>
            <tr>
              <td className="opcjeodst"></td>
              <td>
                <select className="opcje" value={filtr.rozmiar} onChange={zmienFiltr("rozmiar")}>
                  <option value="">Rozmiar</option>
                  {[...Array(10)].map((_, i) => {
                    const size = 35 + i;
                    return <option key={size} value={size}>{size}</option>;
                  })}
                </select>
              </td>
              <td>
                <select className="opcje" value={filtr.kolor} onChange={zmienFiltr("kolor")}>
                  <option value="">Kolor</option>
                  <option value="czarny">Czarny</option>
                  <option value="biały">Biały</option>
                  <option value="czerwony">Czerwony</option>
                  <option value="szary">Szary</option>
                  <option value="rozowy">Różowy</option>
                  <option value="niebieski">Niebieski</option>
                  <option value="zielony">Zielony</option>
                  <option value="kolorowy">Inny</option>
                </select>
              </td>
              <td>
                <select className="opcje" value={filtr.cena} onChange={zmienFiltr("cena")}>
                  <option value="">Cena</option>
                  <option value="malejąco">Malejąco</option>
                  <option value="rosnąco">Rosnąco</option>
                </select>
              </td>
              <td>
                <select className="opcje" value={filtr.marka} onChange={zmienFiltr("marka")}>
                  <option value="">Marka</option>
                  <option value="abibos">Abibos</option>
                  <option value="puma">Puma</option>
                  <option value="nike">Nike</option>
                  <option value="reebok">Reebok</option>
                  <option value="newbalance">New Balance</option>
                  <option value="vans">Vans</option>
                  <option value="fila">Fila</option>
                </select>
              </td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </section>

      <div id="produkty" className="produkty-grid">
        {przefiltrowane.length > 0 ? (
          przefiltrowane.map((produkt) => (
            <div className="infoprodukty" key={produkt.id}>
              <Link to={`/produkt/${produkt.id}`}>
                <img
                  src={obrazki[produkt.nazwa] || AbibosMax35}
                  alt={produkt.nazwa}
                  className="produkt-img"
                />
              </Link>
              <p><strong>Nazwa:</strong> {produkt.nazwa}</p>
              <p><strong>Cena:</strong> {produkt.cena} ZŁ</p>
            </div>
          ))
        ) : (
          <p className="info">Nie znaleziono produktów</p>
        )}
      </div>
    </div>
  );
}

export default Glowna;
