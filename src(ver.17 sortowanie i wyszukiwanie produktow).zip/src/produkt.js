// produkt.js
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase";
import './App.css';
import logo from './Logo.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reeebok Shrek Heels": ReebokShrekHeels,
};

function Produkt() {
  const { id } = useParams();
  const [produkt, setProdukt] = useState(null);
  const [liczba, setLiczba] = useState(1);

  useEffect(() => {
    async function fetchProdukt() {
      const docRef = doc(db, "Products", id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setProdukt({ id: docSnap.id, ...docSnap.data() });
      }
    }
    fetchProdukt();
  }, [id]);

  const zwiekszKoszyk = () => {
    setLiczba(prev => prev + 1);
  };

  if (!produkt) {
    return <p className="info">Ładuję produkt...</p>;
  }

  return (
    <div>
      <header className="App-header">
        <section className="Section">
          <Link to="/">
            <img src={logo} alt="Logo" className="Logo" />
          </Link>
        </section>
      </header>
      <section>
        <img
          src={obrazki[produkt.nazwa] || AbibosMax35}
          alt={produkt.nazwa}
          className="produkt-img"
        />
        <p className="info"><strong>Nazwa:</strong> {produkt.nazwa}</p>
        <p className="info"><strong>Cena:</strong> {produkt.cena} ZŁ</p>
        <p className="info"><strong>Rozmiar: </strong> {produkt.rozmiar}</p>
        <button onClick={zwiekszKoszyk}>Dodaj do koszyka</button>
        <p>Ilość w koszyku: {liczba}</p>
      </section>
    </div>
  );
}

export default Produkt;
