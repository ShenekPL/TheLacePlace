import React from "react";
import { Link } from "react-router-dom";
import { useCart } from "./CartContext";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Koszyk() {
  const { cart, removeFromCart } = useCart();

  // Oblicz sumę
  const suma = cart.reduce((acc, item) => acc + item.cena * item.liczba, 0);

  let zawartosc;

  if (cart.length === 0) {
    zawartosc = (
      <div>
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
            <section className="loginkoszyk">
              <Link to="/login">
                <img src={user} alt="User" className="User" />
                <p className="Logintext">Zaloguj się</p>
              </Link>
            </section>
          </section>
        </header>
        <section className="tla">
          <section className="tlokoszyk1">
            <h2 className="pustykoszh">Twój koszyk jest pusty</h2>
            <p className="pustykoszp">Dodaj produkty do koszyka</p>
          </section>
          <section className="tlokoszyk2">
            <section className="alignbuttons">
              <Link to="/">
                <button className="buttoncontinue">Kontynuuj zakupy</button>
              </Link>
              <Link to="/login">
                <button className="buttonlogin">Zaloguj się</button>
              </Link>
            </section>
          </section>
        </section>
      </div>
    );
  } else {
    zawartosc = (
      <div>
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
          </section>
        </header>
        <section className="tla">
          <h2>Koszyk ({cart.length})</h2>
          <div className="cart-items">
            {cart.map((item) => {
              const imgSrc = obrazki[item.nazwa] || AbibosMax35;
              return (
                <div key={item.id} className="cart-item" style={{display: 'flex', alignItems: 'center', marginBottom: '15px'}}>
                  <img src={imgSrc} alt={item.nazwa} style={{width: '100px', height: 'auto', marginRight: '20px'}} />
                  <p>
                    {item.nazwa} - Kolor: {item.kolor} - Rozmiar: {item.rozmiar} - Ilość: {item.liczba}
                  </p>
                  <button 
                    className="remove-button" 
                    onClick={() => removeFromCart(item.id)}
                    style={{marginLeft: '20px'}}
                  >
                    Usuń
                  </button>
                </div>
              );
            })}
          </div>

          <div className="cart-summary" style={{marginTop: '20px', marginLeft: '20px'}}>
            <h3>Łączna suma: {suma.toFixed(2)} ZŁ</h3>
          </div>

          <Link to="/">
            <button className="buttoncontinue" style={{marginLeft:"20px", marginTop: '15px'}}>Kontynuuj zakupy</button>
          </Link>
        </section>
      </div>
    );
  }

  return <div>{zawartosc}</div>;
}

export default Koszyk;
