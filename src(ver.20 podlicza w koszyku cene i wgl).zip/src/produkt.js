import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase";
import './App.css';
import logo from './Logo.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';
import { useCart } from "./CartContext";

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Produkt() {
  const { id } = useParams();
  const [produkt, setProdukt] = useState(null);
  const [liczba, setLiczba] = useState(1);
  const [wybranyRozmiar, setWybranyRozmiar] = useState(null);
  const { addToCart } = useCart();

  useEffect(() => {
    async function fetchProdukt() {
      const docRef = doc(db, "Products", id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setProdukt({ id: docSnap.id, ...docSnap.data() });
      }
    }
    fetchProdukt();
  }, [id]);

  const zwiekszKoszyk = () => {
    if (wybranyRozmiar) {
      const productToAdd = {
        id: Date.now() + Math.random(), // unikalne ID
        nazwa: produkt.nazwa,
        cena: produkt.cena,
        rozmiar: wybranyRozmiar,
        liczba: liczba,
      };
      addToCart(productToAdd);
      setLiczba(1);
      alert("Produkt dodany do koszyka!");
    }
  };

  if (!produkt) {
    return <p className="info">Ładuję produkt...</p>;
  }

  const pierwszeSlowo = produkt.nazwa.split(" ")[0];
  const resztaNazwy = produkt.nazwa.split(" ").slice(1).join(" ");

  return (
    <div>
      <header className="App-header">
        <section className="Section">
          <Link to="/">
            <img src={logo} alt="Logo" className="Logo" />
          </Link>
        </section>
      </header>

      <section className="produktinfo-container">
        <img
          src={obrazki[produkt.nazwa] || AbibosMax35}
          alt={produkt.nazwa}
          className="produktinfo-img"
        />

        <div className="produkt-info">
          <p className="info">
            <span className="markabuta">{pierwszeSlowo}</span><br />
            <span className="modelbuta">{resztaNazwy}</span>
          </p>
          <p className="cenaprodukt">{produkt.cena} ZŁ</p>

          <p className="info">Rozmiar:</p>
          <div className="rozmiary-container">
            {Array.isArray(produkt.rozmiar) ? (
              produkt.rozmiar.map((rozmiar) => (
                <button
                  key={rozmiar}
                  className={`rozmiar-button ${wybranyRozmiar === rozmiar ? 'wybrany' : ''}`}
                  onClick={() => setWybranyRozmiar(rozmiar)}
                >
                  {rozmiar}
                </button>
              ))
            ) : (
              <p>{produkt.rozmiar}</p>
            )}
          </div>
          <p className="info">Ilość:</p>
          <p><input
            type="number"
            min="1"
            value={liczba}
            onChange={(e) => setLiczba(Number(e.target.value))}
            className="ilosc-input"
          /></p>

          <button
            className={`dodajdokosza ${wybranyRozmiar ? 'aktywny' : ''}`}
            onClick={zwiekszKoszyk}
            disabled={!wybranyRozmiar}
          >
            Dodaj do koszyka
          </button>

          <p className="scaminfo">
            Dostawa w 1-3 dni robocze.<br />
            Brak możliwości zwrotu produktu.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Produkt;
