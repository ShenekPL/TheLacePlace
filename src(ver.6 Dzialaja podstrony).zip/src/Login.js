import { React } from "react";
import { Link } from "react-router-dom";
import mark from './Bardzo intencjonalnie dodane zdjęcie.jpg'; 
import './App.css';
import logo from './Logo.png';
function Login(){
  return (
    <div>
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            <h1>test</h1>
          </section>
        </section>
      </header>
    </div>
  );
}
export default Login;