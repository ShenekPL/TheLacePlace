import React from "react";
import { Link } from "react-router-dom";
import { useCart } from "./CartContext";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Koszyk() {
  const { cart, clearCart, removeFromCart } = useCart();

  let zawartosc;

  if (cart.length === 0) {
    zawartosc = (
      <div>
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
            <section className="loginkoszyk">
              <Link to="/login">
                <img src={user} alt="User" className="User" />
                <p className="Logintext">Zaloguj się</p>
              </Link>
            </section>
          </section>
        </header>
        <section className="tla">
          <section className="tlokoszyk1">
            <h2 className="pustykoszh">Twój koszyk jest pusty</h2>
            <p className="pustykoszp">Dodaj produkty do koszyka</p>
          </section>
          <section className="tlokoszyk2">
            <section className="alignbuttons">
              <Link to="/">
                <button className="buttoncontinue">Kontynuuj zakupy</button>
              </Link>
              <Link to="/login">
                <button className="buttonlogin">Zaloguj się</button>
              </Link>
            </section>
          </section>
        </section>
      </div>
    );
  } else {
    zawartosc = (
      <div className="tlo">
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
          </section>
        </header>
        <section
          className="tla"
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "flex-start",
            gap: "40px",
            paddingTop: "20px",
          }}
        >
        <div style={{ width: "480px" }}>
          <h2>Koszyk ({cart.length})</h2>
          <div className="cart-items">
            {cart.map((item, index) => {
              const imgSrc = obrazki[item.nazwa] || AbibosMax35;
              const nazwaPodzielona = item.nazwa.split(" ");
              return (
                <section
                    className="produktytlo"
                    key={index}
                    style={{
                      paddingTop: "15px",
                      paddingBottom: "5px",
                      width: "450px",
                    }}
                  >
                    <div
                      className="cart-item"
                      style={{
                        display: "flex",
                        alignItems: "center",
                        marginBottom: "5px",
                        marginLeft: "10px",
                      }}
                    >
                      <img
                        src={imgSrc}
                        alt={item.nazwa}
                        style={{
                          width: "100px",
                          height: "auto",
                          marginRight: "20px",
                        }}
                      />
                      <div>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "5px",
                            minWidth: "300px",
                          }}
                        >
                          <span style={{ fontWeight: "bold" }}>
                            {nazwaPodzielona[0]}
                          </span>
                          <span style={{ fontWeight: "bold" }}>
                            {(item.cena * item.liczba).toFixed(2)} ZŁ
                          </span>
                        </div>
                        <span
                          style={{ display: "block", marginBottom: "5px" }}
                        >
                          {nazwaPodzielona.slice(1).join(" ")}
                        </span>
                        <span className="modelbuta" style={{ display: "block" }}>
                          Kolor: {item.kolor}
                        </span>
                        <span className="modelbuta" style={{ display: "block" }}>
                          Rozmiar: {item.rozmiar}
                        </span>
                        <span className="modelbuta" style={{ display: "block" }}>
                          Ilość: {item.liczba}
                        </span>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart({ ...item, index })} className="remove-button"> X Usuń</button>
                  </section>
              );
            })}
          </div>
          </div>
          {/* Prawa kolumna - podsumowanie */}
            <section className="podsumowanie">
              <p className="podsumowanietekst">Podsumowanie</p>
                <hr />
                  <p className="podsumowaniep">
                    Wartość produktów: {suma.toFixed(2)} ZŁ
                    </p>
                    <p className="podsumowaniep">Dostawa: wybierz podczas płatności</p>
                    <hr />
                    <p className="podsumowanietekst">
                      Do zapłaty(z VAT): {suma.toFixed(2)} ZŁ
                    </p>
                    <button className="platnoscguzik" onClick={handleCheckout}>
                      Przejdź do kasy
                    </button>
                    <Link to="/" style={{ marginTop: "20px" }}>
                      <button className="buttoncontinue2">Kontynuuj zakupy</button>
                    </Link>
                    </section>
                  </section>
        </div>
    );
  }

  return <div>{zawartosc}</div>;
}

export default Koszyk;
