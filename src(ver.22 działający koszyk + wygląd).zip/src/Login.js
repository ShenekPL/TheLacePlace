import  React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { doSignInWithEmailAndPassword } from "./Auth";
import { useAuth } from "./AuthContext";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
import Register from "./Register";
function Login(){

  const { userLoggedIn } = useAuth()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isSigningIn, setIsSigningIn] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const onSubmit = async (e) =>{
    e.preventDefault()
    if(!isSigningIn){
      setIsSigningIn(true)
      await doSignInWithEmailAndPassword(email, password).catch(error => {
          switch(error.code){
            case "auth/invalid-credential":
              setErrorMessage("Niepoprawny email lub hasło!");
              break;
          }
        }
      )
    }
  }

  return (
    <div>
      {userLoggedIn && (<Navigate to={'/'} replace={true} />)}
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            {/* trzeba z tego formularz zrobic */}
            {/* już nie trzeba 👍*/}
            <form onSubmit={onSubmit}>
              <h1 className="naglowki">Logowanie</h1>
              <p className="info">Adres e-mail:</p>
              <TextField className="email" value={email} placeholder="przykład@gmail.com" onChange={ (e) => setEmail(e.target.value) } />
              <p className="info">Hasło:</p>
              <TextField className="haslo" value={password} type="password" onChange={ (e) => setPassword(e.target.value)} />
                {errorMessage && (<p className="info">{errorMessage}</p>)}  
              <input className="loginbutton" type="submit" value="ZALOGUJ" /><br/>
            </form>
            <Link to="/Register">
            <input className="registerbutton" type="button" value="REJESTRACJA" />
            </Link>
          </section>
        </section>
      </header>
    </div>
  );
}
export default Login;