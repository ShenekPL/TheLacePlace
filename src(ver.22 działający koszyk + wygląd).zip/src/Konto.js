import  React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { doSignOut } from "./Auth";
import logo from './Logo.png';
import user from './user.png';
import './App.css';
function Konto(){

  const  { currentUser } = useAuth()
  return (
    <div>
        <header className="App-header">
            <section className="Section">
            <Link to="/">
                <img src={logo} alt="Logo" className="Logo" />
            </Link>
            </section>
        </header>
        <h1 className="info" style={{textAlign: "center", fontSize: "30px"}}>Zalogowany jako: {currentUser.email}</h1>
        <Link to="/"><input type="button" className="loginbutton" onClick={doSignOut} value="Wyloguj się"/></Link>
    </div>
  );
}
export default Konto;