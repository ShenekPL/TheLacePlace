import { React } from "react";
import { Link } from "react-router-dom";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
function koszyk(){
    // ta wartosc bedzie zmieniana przy dodawaniu rzeczy do koszyka
     const liczba = 1;
    return(
        <div>
            <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        </header>
        {/* Tutaj w zaleznosci czy cos jest w koszyku czy nie bedzie wyswietlac odpowiednie elementy */}
        {liczba === 1 && <p>koszyk1</p>}
      {liczba === 2 && <p>koszyk2</p>}
        <p>TUTAJ KOSZYK</p>
        </div>
    );
}
export default koszyk;