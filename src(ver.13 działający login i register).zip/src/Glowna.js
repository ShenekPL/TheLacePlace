import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./firebase.js";
import { Link } from "react-router-dom";
import TextField from "@mui/material/TextField";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';

function Glowna() {
  const [liczba, setLiczba] = useState(1);
  const [produkty, setProdukty] = useState([]);

  const zwiekszKoszyk = () => {
    setLiczba(prev => prev + 1);
  };

  useEffect(() => {
    async function fetchProdukty() {
      const querySnapshot = await getDocs(collection(db, "Products"));
      const listaProduktow = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setProdukty(listaProduktow);
    }

    fetchProdukty();
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <section className="Section">
          <img src={logo} alt="Logo" className="Logo" />
          <div className="Search">
            <TextField
              id="SearchBar"
              variant="filled"
              fullWidth
              placeholder="Szukaj"
            />
          </div>
          <section className="Buttons">
            <Link to="/login">
              <img src={user} alt="User" className="User" />
              <p className="Logintext">Zaloguj się</p>
            </Link>
            <Link to="/koszyk" state={{ liczba }}>
              <img src={cart} alt="Cart" className="Cart" />
              <p className="Carttext">Koszyk</p>
            </Link>
          </section>
        </section>
        <section className="Section2">
          <table className="Table" id="table">
            <tbody>
              <tr>
                <td></td>
                <td className="Jeden">Specjalne Oferty</td>
                <td>Nowa Kolekcja</td>
                <td>Dziecięce</td>
                <td>Damskie</td>
                <td>Męskie</td>
                <td>Sportowe</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </section>
      </header>

      <div id="produkty">
        <section className="Section3">
          {/* Dropdowny z filtrami */}
          <table>
            <tbody>
              <tr>
                <td className="opcjeodst"></td>
                <td>
                  <select className="opcje">
                    <option defaultValue>Rozmiar</option>
                    {[...Array(11)].map((_, i) => {
                      const size = 36 + i;
                      return <option key={size} value={size}>{size}</option>;
                    })}
                  </select>
                </td>
                <td>
                  <select className="opcje">
                    <option defaultValue>Kolor</option>
                    <option value="czarny">Czarny</option>
                    <option value="biały">Biały</option>
                    <option value="czerwony">Czerwony</option>
                    <option value="szary">Szary</option>
                    <option value="różowy">Różowy</option>
                    <option value="niebieski">Niebieski</option>
                    <option value="kolorowy">Inny</option>
                  </select>
                </td>
                <td>
                  <select className="opcje">
                    <option defaultValue>Cena</option>
                    <option value="malejąco">Malejąco</option>
                    <option value="rosnąco">Rosnąco</option>
                  </select>
                </td>
                <td>
                  <select className="opcje">
                    <option defaultValue>Marka</option>
                    <option value="adidas">Adidas</option>
                    <option value="puma">Puma</option>
                    <option value="nike">Nike</option>
                    <option value="reebok">Reebok</option>
                    <option value="newbalance">New Balance</option>
                    <option value="vans">Vans</option>
                    <option value="fila">Fila</option>
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
        </section>

        {produkty.length > 0 ? (
          produkty.map((produkt) => (
            <div className="info" key={produkt.id}>
              <p><strong>Nazwa:</strong> {produkt.nazwa}</p>
              <p><strong>Cena:</strong> {produkt.cena} ZŁ</p>
              <p><strong>Marka:</strong> {produkt.marka}</p>
              <p><strong>Kategoria:</strong> {produkt.kategoria}</p>
              <p><strong>Rozmiar:</strong> {produkt.rozmiar}</p>
              <p><strong>Kolor:</strong> {produkt.kolor}</p>
              <p><strong>Sportowe:</strong> {produkt.sportowe ? "Tak" : "Nie"}</p>
              <button onClick={zwiekszKoszyk}>Dodaj do koszyka</button>
            </div>
          ))
        ) : (
          <p className="info">Ładuję produkty...</p>
        )}
      </div>
    </div>
  );
}

export default Glowna;
