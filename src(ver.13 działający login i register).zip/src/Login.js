import  React, { useState } from "react";
import { Link } from "react-router-dom";
import { app, auth } from "./firebase";
import { signInWithEmailAndPassword } from "firebase/auth";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
import Register from "./Register";
function Login(){

  const [email, setEmail] = useState('');
  const [password, SetPassword] = useState('');
  const signIn = (e) =>{
      e.preventDefault();
      signInWithEmailAndPassword(auth, email, password)
      .then((userCredencial) =>{
        // Signed In
        console.log(userCredencial.user);
        // ...
      })
      .catch((error) =>{
        console.log(error);
      });
  }

  return (
    <div>
      <header className="App-header">
        <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
        <section className="LoginBg">
          <section className="LoginFg">
            {/* trzeba z tego formularz zrobic */}
            {/* już nie trzeba 👍*/}
            <form onSubmit={signIn}>
              <h1 className="naglowki">Logowanie</h1>
              <p className="info">Adres e-mail:</p>
              <TextField className="email" value={email} placeholder="przykład@gmail.com" onChange={ (e) => setEmail(e.target.value) } />
              <p className="info">Hasło:</p>
              <TextField className="haslo" value={password} type="password" onChange={ (e) => SetPassword(e.target.value)} />
              <input className="loginbutton" type="submit" value="ZALOGUJ" /><br/>
            </form>
            <Link to="/Register">
            <input className="registerbutton" type="button" value="REJESTRACJA" />
            </Link>
          </section>
        </section>
      </header>
    </div>
  );
}
export default Login;