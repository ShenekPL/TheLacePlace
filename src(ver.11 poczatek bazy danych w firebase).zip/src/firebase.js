import { initializeApp } from 'firebase/app';
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from 'firebase/firestore';
// Follow this pattern to import other Firebase services
// import { } from 'firebase/<service>';
const firebaseConfig = {
  apiKey: "AIzaSyCXqtXTVfD2Y1iCFuEwpIbWKqmcImx5JoI",
  authDomain: "thelaceplace-5b6d5.firebaseapp.com",
  projectId: "thelaceplace-5b6d5",
  storageBucket: "thelaceplace-5b6d5.firebasestorage.app",
  messagingSenderId: "331403682294",
  appId: "1:331403682294:web:4939f03937082da6d0a7d7",
  measurementId: "G-236G87RF8W"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const analytics = getAnalytics(app);

export {db};


// const addProduct = async (newProduct) => {
//     await db.collection('Products').add(newProduct);
// };
//moze sie kiedys przydac