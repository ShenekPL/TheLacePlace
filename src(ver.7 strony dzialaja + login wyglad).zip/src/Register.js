import { React } from "react";
import { Link } from "react-router-dom";
import './App.css';
import TextField from "@mui/material/TextField";
import logo from './Logo.png';
function register(){
    return(
        <div>
            <header className="App-header">
                <section className="Section">
      <Link to="/">
      <img src={logo} alt="Logo" className="Logo" />
                </Link>
        </section>
            </header>
        </div>
    )
}
export default register;