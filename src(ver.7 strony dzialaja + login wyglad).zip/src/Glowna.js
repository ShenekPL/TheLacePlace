import { React } from "react";
import { Link } from "react-router-dom";
import TextField from "@mui/material/TextField";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import cart from './cart.png';
import Login from "./Login";

function Glowna(){
    return(
        <div className="App">
          <header className="App-header">
            <section className="Section">
              <img src={logo} alt="Logo" className="Logo" />
              <div className="Search">
                <TextField
                  id="SearchBar"
                  variant="filled"
                  fullWidth
                  placeholder="Szukaj" />
              </div>
              <section className="Buttons">
                <Link to="/login">
                  <img src={user} alt="User " className="User " />
                  <p className="Logintext">Zaloguj się</p>
                </Link>
                <a href="https://youtube.com/">
                  <img src={cart} alt="Cart" className="Cart" />
                  <p className="Carttext">Koszyk</p>
                </a>
              </section>
            </section>
            <section className="Section2">
              <table className="Table" id="table">
                <tr>
                  <td></td>
                  <td className="Jeden">Specjalne Oferty</td>
                  <td>Nowa Kolekcja</td>
                  <td>Dziecięce</td>
                  <td>Damskie</td>
                  <td>Męskie</td>
                  <td>Sportowe</td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </table>
            </section>
          </header>
          <div id="produkty">
            <section className="Section3">
              <table>
                <tr>
                  <td></td>
                  <td>
                    <select>
                      <option defaultValue>Rozmiar</option>
                      <option value="36">36</option>
                      <option value="37">37</option>
                      <option value="38">38</option>
                      <option value="39">39</option>
                      <option value="40">40</option>
                      <option value="41">41</option>
                      <option value="42">42</option>
                      <option value="43">43</option>
                      <option value="44">44</option>
                      <option value="45">45</option>
                      <option value="46">46</option>
                    </select>
                  </td>
                  <td>
                    <select>
                      <option defaultValue>Kolor</option>
                      <option value="czarny">Czarny</option>
                      <option value="biały">Biały</option>
                      <option value="czerwony">Czerwony</option>
                      <option value="szary">Szary</option>
                      <option value="różowy">Różowy</option>
                      <option value="niebieski">Niebieski</option>
                      <option value="kolorowy">Inny</option>
                    </select>
                  </td>
                  <td>
                    <select>
                      <option defaultValue>Cena</option>
                      <option value="malejąco">Malejąco</option>
                      <option value="rosnąco">Rosnąco</option>
                    </select>
                  </td>
                  <td>
                    <select>
                      <option defaultValue>Marka</option>
                      <option value="adidas">Adidas</option>
                      <option value="puma">Puma</option>
                      <option value="nike">Nike</option>
                      <option value="reebok">Reebok</option>
                      <option value="newbalance">New Balance</option>
                      <option value="vans">Vans</option>
                      <option value="fila">Fila</option>
                    </select>
                  </td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </table>
              </section>
          </div>
        </div>
    );
}
export default Glowna;