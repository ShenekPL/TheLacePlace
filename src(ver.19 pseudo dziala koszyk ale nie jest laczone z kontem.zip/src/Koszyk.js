import React from "react";
import { Link } from "react-router-dom";
import { useCart } from "./CartContext";
import './App.css';
import logo from './Logo.png';
import user from './user.png';
import AbibosMax35 from './zdjecia/AbibosMax35.png';
import AbibosUltraHyper5 from './zdjecia/AbibosUltraHyper5.png';
import AbibosPrimeWhite from './zdjecia/AbibosPrimeWhite.png';
import FilaUglyAssShoes from './zdjecia/FilaUglyAssShoes.png';
import ReebokShrekHeels from './zdjecia/ReebokShrekHeels.png';

const obrazki = {
  "Abibos Max 35": AbibosMax35,
  "Abibos Ultra Hyper 5": AbibosUltraHyper5,
  "Abibos Prime White": AbibosPrimeWhite,
  "Fila Ugly Ass Shoes": FilaUglyAssShoes,
  "Reebok Shrek Heels": ReebokShrekHeels,
};

function Koszyk() {
  const { cart, clearCart } = useCart();

  let zawartosc;

  if (cart.length === 0) {
    zawartosc = (
      <div>
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
            <section className="loginkoszyk">
              <Link to="/login">
                <img src={user} alt="User" className="User" />
                <p className="Logintext">Zaloguj się</p>
              </Link>
            </section>
          </section>
        </header>
        <section className="tla">
          <section className="tlokoszyk1">
            <h2 className="pustykoszh">Twój koszyk jest pusty</h2>
            <p className="pustykoszp">Dodaj produkty do koszyka</p>
          </section>
          <section className="tlokoszyk2">
            <section className="alignbuttons">
              <Link to="/">
                <button className="buttoncontinue">Kontynuuj zakupy</button>
              </Link>
              <Link to="/login">
                <button className="buttonlogin">Zaloguj się</button>
              </Link>
            </section>
          </section>
        </section>
      </div>
    );
  } else {
    zawartosc = (
      <div>
        <header className="App-header">
          <section className="Section">
            <Link to="/">
              <img src={logo} alt="Logo" className="Logo" />
            </Link>
          </section>
        </header>
        <section className="tla">
          <h2>Koszyk ({cart.length})</h2>
          <div className="cart-items">
            {cart.map((item, index) => {
              const imgSrc = obrazki[item.nazwa] || AbibosMax35;
              return (
                <div key={index} className="cart-item" style={{display: 'flex', alignItems: 'center', marginBottom: '15px'}}>
                  <img src={imgSrc} alt={item.nazwa} style={{width: '100px', height: 'auto', marginRight: '20px'}} />
                  <p>{item.nazwa} - Rozmiar: {item.rozmiar}</p>
                </div>
              );
            })}
          </div>
          <button className="buttoncontinue" onClick={clearCart}>Wyczyść koszyk</button>
          <Link to="/">
            <button className="buttoncontinue" style={{marginLeft:"20px"}}>Kontynuuj zakupy</button>
          </Link>
        </section>
      </div>
    );
  }

  return <div>{zawartosc}</div>;
}

export default Koszyk;

