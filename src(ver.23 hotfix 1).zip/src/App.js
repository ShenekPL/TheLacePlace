import { React } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Login from "./Login";
import Glowna from "./Glowna";
import Register from "./Register";
import Koszyk from "./Koszyk";
import Produkt from "./produkt";
import Konto from "./Konto";
import { AuthProvider } from "./AuthContext";
import { CartProvider } from "./CartContext";

function App() {
  return (
    <>
      <BrowserRouter>
        <AuthProvider>
          <CartProvider>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/koszyk" element={<Koszyk />} />
              <Route path="/produkt/:id" element={<Produkt />} />
              <Route path="/konto" element={<Konto />} />
              <Route index element={<Glowna/>} />
            </Routes>
          </CartProvider>
        </AuthProvider>
      </BrowserRouter>
    </>
  );
}

export default App;
